#include "headers.h"

using namespace std;

int main()
{

    srand(time(NULL));
    BITMAP* doublebuffer=NULL;

    Map MAP;
    MAP.initialisationAllegro();
    MAP.affichage(doublebuffer);

    return 0;
}END_OF_MAIN();
