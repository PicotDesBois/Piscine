#include "aeroport.h"

using namespace std;

int main()
{
    srand(time(NULL));
    Graphe g{"aeroport.txt"};

    g.afficher();

    return 0;
}
