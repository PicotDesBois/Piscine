#ifndef MAP_H_INCLUDED
#define MAP_H_INCLUDED
#include "headers.h"

class Map
{

   private :
       /***Attributs***/

       BITMAP* m_planisphere;
       int m_positionX;
       int m_positionY;

   public :
    /***Constructeur & Destructeur ***/
    Map();
    ~Map();

    /***Accesseurs***/
    int getX();
    int getY();
    BITMAP* getPlanisphere();

    /***M�thodes***/
    void affichage(BITMAP *doublebuffer);
    void initialisationAllegro();
    void affichage_coordonnees(BITMAP *doublebuffer);
    void affichage_sommet(BITMAP* doublebuffer);
    void affichage_arete(BITMAP* doublebuffer);
    void affichage_image(BITMAP* doublebuffer);
    void affichage_quadrillage(BITMAP* doublebuffer);
    void Dijkstra();
    void affichageDijkstra(Aeroport*sommet);


};

#endif // MAP_H_INCLUDED
