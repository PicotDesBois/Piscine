#ifndef HEADERS_H_INCLUDED
#define HEADERS_H_INCLUDED

#include <allegro.h>
#include <bits/stdc++.h>
#include <time.h>
#include <conio.h>

#include <iostream>
#include <vector>
#include <fstream>

#include "Avions.h"
#include "aeroport.h"
#include "map.h"

#endif // HEADERS_H_INCLUDED
