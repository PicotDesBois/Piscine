#include "headers.h"
using namespace std;

void Map::initialisationAllegro()
{
    allegro_init();
    install_keyboard();
    install_mouse();

    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED,1200,650,0,0))!=0)
    {
        allegro_message("Pb de mode graphique") ;
        allegro_exit();
        exit(EXIT_FAILURE);
    }

    show_mouse(screen);   /// pour avoir la souris dans la console de compilation
    install_sound(DIGI_AUTODETECT,MIDI_AUTODETECT,NULL);
}

Map::Map()

{
    m_positionX=0;
    m_positionY=0;
}


Map::~Map()
{

}

BITMAP*Map::getPlanisphere()
{
    return m_planisphere;
}

int Map::getX()
{
    return m_positionX;
}
int Map::getY()
{
    return m_positionY;
}


void Map::affichage_coordonnees(BITMAP *doublebuffer)
{
    textprintf_ex(doublebuffer,font, 1060, 20,makecol(0,0,0),-1, " x: %d y: %d", mouse_x,mouse_y);
    textprintf_ex(doublebuffer,font, 1060, 20,makecol(0,0,0),-1, " x: %d y: %d", mouse_x,mouse_y);
}

void Map::affichage_image(BITMAP* doublebuffer)
{
    m_planisphere=load_bitmap("images/planisphere.bmp",NULL);
    blit(getPlanisphere(),doublebuffer, 0, 0,getX(), getY(), getPlanisphere()->w, getPlanisphere()->h);
    destroy_bitmap(getPlanisphere());
}

void Map::affichage_sommet(BITMAP* doublebuffer)
{
    circlefill(doublebuffer,580,240,5,makecol(255,0,0)); ///PARIS
    circlefill(doublebuffer,320,275,5,makecol(255,0,0)); ///NEW YORK
    circlefill(doublebuffer,740,325,5,makecol(255,0,0)); ///DUBAI
    circlefill(doublebuffer,1020,292,5,makecol(255,0,0)); ///TOKYO
    circlefill(doublebuffer,1060,530,5,makecol(255,0,0)); ///SYDNEY
    circlefill(doublebuffer,660,530,5,makecol(255,0,0)); ///CAP TOWN
    circlefill(doublebuffer,440,479,5,makecol(255,0,0)); ///RIO
}

void Map::affichage_arete(BITMAP* doublebuffer)
{
    line(doublebuffer,320,275,580,240,makecol(255,0,0)); ///ar�te NY vers Paris
    line(doublebuffer,580,240,1020,292,makecol(255,0,0)); ///ar�te Paris vers Tokyo
    line(doublebuffer,1020,292,1060,530,makecol(255,0,0)); ///ar�te Tokyo vers Sydney
    line(doublebuffer,1060,530,660,530,makecol(255,0,0)); ///ar�te Sydney vers Cap Town
    line(doublebuffer,660,530,440,479,makecol(255,0,0)); ///ar�te Cap Town vers Rio
    line(doublebuffer,440,479,320,275,makecol(255,0,0)); ///ar�te Rio vers NY
    line(doublebuffer,320,275,660,530,makecol(255,0,0)); ///ar�te NY vers Cap Town
    line(doublebuffer,580,240,660,530,makecol(255,0,0)); ///ar�te Paris vers Cap Town
    line(doublebuffer,580,240,740,325,makecol(255,0,0)); ///ar�te Paris vers Duba�
    line(doublebuffer,740,325,660,530,makecol(255,0,0)); ///ar�te Duba� vers Cap Town
    line(doublebuffer,740,325,1060,530,makecol(255,0,0)); ///ar�te Duba� vers Sydney
    line(doublebuffer,320,275,1020,292,makecol(255,0,0)); ///ar�te NY vers Tokyo
}

void Map::affichage_quadrillage(BITMAP* doublebuffer)
{
    int i;
    int j;
    for(i=0;i<39;i++)
    {
        for(j=0;j<20;j++)
        {
            hline(doublebuffer,310,215+17*j,1070,makecol(0,0,0));
            vline(doublebuffer,310+20*i,215,538,makecol(0,0,0));

        }
    }
}


void Map::affichage(BITMAP *doublebuffer)
{
    std::string Aeroport1er,Aeroport2eme;

    Graphe g{"aeroport.txt"};
    g.afficher();

    doublebuffer=create_bitmap(SCREEN_W,SCREEN_H);

    m_planisphere=load_bitmap("images/planisphere.bmp",NULL);

    while(!key[KEY_ESC])
    {

        clear_bitmap(doublebuffer);

        affichage_image(doublebuffer);
        affichage_coordonnees(doublebuffer);
        affichage_quadrillage(doublebuffer);
        affichage_arete(doublebuffer);
        affichage_sommet(doublebuffer);

         if(mouse_b&1)
        {
            for(auto aeroport:g.getListeAeroport())
            {
                if(mouse_x>aeroport->getX()&&mouse_x<aeroport->getX()+20&&mouse_y>aeroport->getY()&&mouse_y<aeroport->getY()+17)
                    aeroport->afficher();
            }
            for(auto avion:g.getListeAvions())
            {
                if(mouse_x>avion->getX()&&mouse_x<avion->getX()+20&&mouse_y>avion->getY()&&mouse_y<avion->getY()+17)
                    avion->afficher();
            }
        }
        g.Naif();
        for(auto avion:g.getListeAvions())
        {
            std::cout<<" avion "<<avion->getIdentifiant();
            std::cout<<" altitude "<<avion->getAltitude()<<std::endl;
        }

        g.gestionAeroport();
        g.gestionVol(doublebuffer);

        blit(doublebuffer,screen,0,0,0,0,SCREEN_W,SCREEN_H);///affichage du double Buffer
        rest(1000);

    }

    destroy_bitmap(doublebuffer);
}

